using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.ProBuilder")]
